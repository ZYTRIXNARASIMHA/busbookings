import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <app-card></app-card>
  `,
})
export class HomeComponent {}
